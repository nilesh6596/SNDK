// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  auth: {
    protocol: 'http',
    port: '3000',
    apiPrefix: '/api/project',
    userlogin: '/user/login',
    registeruser: '/user/signUp',
    editPostMgmt: '/edit/post',
    deletePostMgmt: '/delete/post',
    addPostMgmt: '/add/post',
    savePostDetail: '/add/post/detail',
    editPostDetail: '/edit/post/data/:post_id',
    getCategoryDetail: '/get/category/data',
    getPostData: '/get/post/data',
    getPostDataById: '/get/post/data/:post_id',
    getPostDataByName: '/get/post/data/postName',
  }
};
