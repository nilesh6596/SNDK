export const environment = {
  production: true,
  auth: {
    protocol: 'http',
    port: '3000',
    apiPrefix: '/api/project',
    userlogin: '/user/login',
    registeruser: '/user/signUp',
    editPostMgmt: '/edit/post',
    deletePostMgmt: '/delete/post',
    addPostMgmt: '/add/post',
    savePostDetail: '/add/post/detail',
    editPostDetail: '/edit/post/data/:post_id',
    getCategoryDetail: '/get/category/data',
    getPostData: '/get/post/data',
    getPostDataById: '/get/post/data/:post_id',
    getPostDataByName: '/get/post/data/postName',
  },
};