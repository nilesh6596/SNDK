import { TestBed, inject } from '@angular/core/testing';

import { LinkgenerationService } from './linkgeneration.service';

describe('LinkgenerationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LinkgenerationService]
    });
  });

  it('should be created', inject([LinkgenerationService], (service: LinkgenerationService) => {
    expect(service).toBeTruthy();
  }));
});
