import { Injectable, Inject } from '@angular/core';
import { LOCAL_STORAGE, WebStorageService } from 'angular-webstorage-service';
import { Http, Headers, Response, RequestOptions, ResponseContentType } from '@angular/http';


@Injectable()
export class LinkgenerationService {

  constructor(
    @Inject(LOCAL_STORAGE)private _sessionstorage: WebStorageService,
  ) { }

  linkGeneration(param1, param2) {
    const host = window.location.hostname;
    return param1.protocol + '://' + host + ':' + param1.port + param1.apiPrefix + param2;
  }

  setHeaderWithParams(params) {
    const headers = new Headers();
    const userCode = this._sessionstorage.get('userCode');
    const authToken = this._sessionstorage.get('token');
    headers.append('user_code', userCode);
    headers.append('token', authToken);
    return new RequestOptions({ headers: headers, params: params });
  }

}
