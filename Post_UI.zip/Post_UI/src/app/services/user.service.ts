import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { environment } from '../../environments/environment';
import { LinkgenerationService } from './linkgeneration.service';

@Injectable()
export class UserService {

  constructor(
    private _http: HttpClient,
    private _linkgenerationservice: LinkgenerationService) { }

  getUserDetailsLOginAPI (body) {
    const getUrlLink = this._linkgenerationservice.linkGeneration(environment.auth, environment.auth.userlogin);
    return this._http.post(getUrlLink, body)
      .map(response => {
        return response;
      })
      .catch(error => {
        return error.json();
      });
  }
}
