import { Injectable, OnInit, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { BehaviorSubject, Observable } from 'rxjs';
import { WebStorageService, LOCAL_STORAGE } from 'angular-webstorage-service';


@Injectable()
export class AuthenticationService implements OnInit {

  constructor(
    private http: HttpClient,
    @Inject(LOCAL_STORAGE)private _sessionstorage: WebStorageService
  ) { }

  ngOnInit() {}

  logout() {
    // remove user from local storage and set current user to null
    this._sessionstorage.remove('name');
}
}
