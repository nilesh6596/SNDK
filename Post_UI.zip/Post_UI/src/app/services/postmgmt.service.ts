import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { ToasterService } from 'angular2-toaster';
import { LinkgenerationService } from './linkgeneration.service';
import { environment } from '../../environments/environment';

@Injectable()
export class PostmgmtService {

  constructor(
    private _http: Http,
    public _toasterService: ToasterService,
    private _linkgenerationservice: LinkgenerationService,

  ) { }

  addPostPublistAPI (body) {
    const params = {};
    const getUrlLink = this._linkgenerationservice.linkGeneration(environment.auth, environment.auth.savePostDetail);
    return this._http.post(getUrlLink, body, this._linkgenerationservice.setHeaderWithParams(params))
      .map(response => {
        return response.json();
      })
      .catch(error => {
        return error.json();
      });
  }

  getCategoryDataAPI () {
    const params = {};
    const getUrlLink = this._linkgenerationservice.linkGeneration(environment.auth, environment.auth.getCategoryDetail);
    return this._http.get(getUrlLink, this._linkgenerationservice.setHeaderWithParams(params))
      .map(response => {
        return response.json();
      })
      .catch(error => {
        return error.json();
      });
  }

  getPostDataAPI (pagination) {
    const params = {};
    const par = {};
    params['offset'] = pagination.offset;
    params['limit'] = pagination.limit;
    const getUrlLink = this._linkgenerationservice.linkGeneration(environment.auth, environment.auth.getPostData);
    return this._http.get(getUrlLink, this._linkgenerationservice.setHeaderWithParams(params))
      .map(response => {
        return response.json();
      })
      .catch(error => {
        return error.json();
      });
  }

  deletePostDataAPI (postId) {
    const params = {};
    params['postId'] = postId;
    const getUrlLink = this._linkgenerationservice.linkGeneration(environment.auth, environment.auth.deletePostMgmt);
    return this._http.delete(getUrlLink, this._linkgenerationservice.setHeaderWithParams(params))
      .map(response => {
        return response.json();
      })
      .catch(error => {
        return error.json();
      });
  }

  getPostDataByIdAPI (postId) {
    const params = {};
    params['postId'] = postId;
    let getUrlLink = this._linkgenerationservice.linkGeneration(environment.auth, environment.auth.getPostDataById);
    getUrlLink = getUrlLink.replace(':post_id', postId);
    return this._http.get(getUrlLink, this._linkgenerationservice.setHeaderWithParams(params))
      .map(response => {
        return response.json();
      })
      .catch(error => {
        return error.json();
      });
  }

  updatePostDataAPI (body, postId) {
    const params = {};
    params['postId'] = postId;
    let getUrlLink = this._linkgenerationservice.linkGeneration(environment.auth, environment.auth.editPostDetail);
    getUrlLink = getUrlLink.replace(':post_id', postId);
    return this._http.put(getUrlLink, body, this._linkgenerationservice.setHeaderWithParams(params))
      .map(response => {
        return response.json();
      })
      .catch(error => {
        return error.json();
      });
  }

  getPostDataSearchAPI (body) {
    const params = {};
    const getUrlLink = this._linkgenerationservice.linkGeneration(environment.auth, environment.auth.getPostDataByName);
    return this._http.post(getUrlLink, body, this._linkgenerationservice.setHeaderWithParams(params))
      .map(response => {
        return response.json();
      })
      .catch(error => {
        return error.json();
      });
  }


}
