import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { LinkgenerationService } from './linkgeneration.service';
import { environment } from '../../environments/environment';

@Injectable()
export class RegisterService {

  constructor(
    private _http: HttpClient,
    private _linkgenerationservice: LinkgenerationService) { }

    getUserDetailsRegisterAPI (body) {
      const getUrlLink = this._linkgenerationservice.linkGeneration(environment.auth, environment.auth.registeruser);
    return this._http.post(getUrlLink, body)
      .map(response => {
          return response;
      })
      .catch(error => {
        return error.json();
      });
  }
}

