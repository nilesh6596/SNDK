import { TestBed, inject } from '@angular/core/testing';

import { PostmgmtService } from './postmgmt.service';

describe('PostmgmtService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PostmgmtService]
    });
  });

  it('should be created', inject([PostmgmtService], (service: PostmgmtService) => {
    expect(service).toBeTruthy();
  }));
});
