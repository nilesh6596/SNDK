import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegisterService } from '../../services/register.service';
import { ToasterService } from 'angular2-toaster';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

public requestJson = this.createRequestJson();

constructor(
  private _router: Router,
  private _registerUserService: RegisterService,
  public _toasterService: ToasterService
) { }

ngOnInit() {
  }

createRequestJson() {
    const requestJson = {};
    requestJson['name'] = '';
    requestJson['email'] = '';
    requestJson['password'] = '';
    return requestJson;
  }

submit(form) {
    if (form.valid) {
        const formValues = form.value;
        this.registerUser(formValues);
      }
  }

popUpService(status, title, text) {
    this._toasterService.pop(status, title, text);
 }
registerUser(formValues) {
    return new Promise(async (resolve, reject) => {
          const body = {};
          body['name'] = formValues.name;
          body['email'] = formValues.email;
          body['password'] = formValues.password;
          this._registerUserService.getUserDetailsRegisterAPI(body).subscribe(async (response: any) => {
            if (response && response.status_code === 200) {
              this.popUpService('success', 'SUCCESS', 'User registered successfully..!!');
                this._router.navigate(['/login']);
            } else {
                  alert('Failed to registered in..!!');
            }
            resolve(response);
          },
          error => {
            this.popUpService('error', 'ERROR', 'Something went wrong..!!');
          });
        });
}

}
