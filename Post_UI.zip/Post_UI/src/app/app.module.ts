import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { routing } from './app.routing';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login/login.component';
import { RegisterComponent } from './register/register/register.component';
import { AuthenticationService } from './services/authentication.service';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { UserService } from './services/user.service';
import { AlertService } from './services/alert.service';
import { RegisterService } from './services/register.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGuard } from './dashboard/auth.guard';
import { StorageServiceModule} from 'angular-webstorage-service';
import { ToasterModule, ToasterService } from 'angular2-toaster';
import { LinkgenerationService } from './services/linkgeneration.service';
import { HttpModule } from '@angular/http';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    routing,
    FormsModule,
    HttpClientModule,
    HttpModule,
    BrowserAnimationsModule,
    StorageServiceModule,
    ToasterModule
  ],
  providers: [ AlertService,
               AuthenticationService,
               UserService,
               RegisterService,
               AuthGuard,
               ToasterService,
               LinkgenerationService
             ],
  bootstrap: [AppComponent]
})
export class AppModule { }
