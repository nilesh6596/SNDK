import { Injectable, Inject } from '@angular/core';
import { CanActivate, CanActivateChild, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import { WebStorageService, LOCAL_STORAGE } from 'angular-webstorage-service';

@Injectable()
export class AuthGuard implements CanActivateChild {

  constructor(
    private router: Router,
    @Inject(LOCAL_STORAGE)private _sessionstorage: WebStorageService)
  {
  }

  canActivateChild(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      if (this._sessionstorage.get('UserLoggedIn') === 'true') {
        return true;
    } else {
        this.router.navigate(['/login']);
        return false;
    }
  }
}
