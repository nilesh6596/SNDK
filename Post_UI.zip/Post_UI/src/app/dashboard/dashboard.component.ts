import { Component, OnInit, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { LOCAL_STORAGE, WebStorageService } from 'angular-webstorage-service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  public requestJson = this.createRequestJson();
  public name: string;

  constructor(
    private _router: Router,
    @Inject(LOCAL_STORAGE)private _sessionstorage: WebStorageService

  ) { }

  ngOnInit() {
    this.name = this._sessionstorage.get('name');
  }

  createRequestJson() {
    const requestJson = {};
    requestJson['companyname'] = '';
    requestJson['employeename'] = '';
    return requestJson;
  }

  // navigateHome () {
  //   this._router.navigate(['/home']);
  // }

  // navigateCompany () {
  //   this._router.navigate(['comemp/company']);
  // }

  // navigateEmployee () {
  //   this._router.navigate(['comemp/employee']);
  // }

  // navigateContact () {
  //   this._router.navigate(['contact']);
  // }
}
