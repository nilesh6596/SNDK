import { Component, OnInit, ViewChild, ElementRef, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { ToasterService } from 'angular2-toaster';
import { PostmgmtService } from '../../services/postmgmt.service';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {

  @ViewChild('postName') nameTextbox: ElementRef;
  public requestJson = this.createRequestJson();
  public categoryList: any[];
  public status: any;

  constructor(
    private _router: Router,
    private _postService: PostmgmtService,
    public _toasterService: ToasterService
  ) { }

  ngOnInit() {
    this.nameTextbox.nativeElement.focus();
    this.getCategoryList();
  }

  async getCategoryList() {
    await this.getCategoryData();
  }

  createRequestJson() {
    const requestJson = {};
    requestJson['name'] = '';
    requestJson['description'] = '';
    requestJson['category'] = '';
    return requestJson;
  }


  submit(form) {
    if (form.valid) {
        const formValues = form.value;
        this.status = 1;
        this.addPostData(formValues);
    } else {
        this.setFocusToInvalidElement(form);
      }
  }

  cancel(form) {
        const formValues = form.value;
        this.status = 0;
        this.addPostData(formValues);
  }

  // focus to invalid input fields
  setFocusToInvalidElement(form) {
    if (!form.valid) {
      let target;
      target = document.getElementsByClassName('ng-invalid')[1];
      if (target) {
        target.focus();
      }
    }
  }

  // toaster popup message
  popUpService(status, title, text) {
    this._toasterService.pop(status, title, text);
 }


 // add post data api call
 addPostData(formValues) {
    return new Promise(async (resolve, reject) => {
          const body = {};
          body['name'] = formValues.name;
          body['description'] = formValues.description;
          body['category'] = formValues.category;
          body['status'] = this.status;
          this._postService.addPostPublistAPI(body).subscribe(async (response: any) => {
            if (response && response.status_code === 200) {
              if (response.data[0].status === 1) {
                this.popUpService('success', 'SUCCESS', 'Post published successfully..!!');
              } else {
                this.popUpService('info', 'INFO', 'Post drfated successfully..!!');
              }
              this._router.navigate(['/home']);
            } else {
              this.popUpService('error', 'ERROR', 'Failed to publish the post..!!');
            }
            resolve(response);
          },
          error => {
            this.popUpService('error', 'ERROR', 'Something went wrong..!!');
          });
        });
  }

  // fetch category list api call
  getCategoryData() {
        return new Promise((resolve, reject) => {
          this._postService.getCategoryDataAPI().subscribe((response) => {
            if (response.status_code === 200) {
              const categoryData = response.data;
              const list = [];
              categoryData.forEach(element => {
                list.push(element.category_name);
              });
              this.categoryList = list;
            }
            resolve();
          }, (error) => {
            this.popUpService('exception', 'Session Expired', 'Exception');
            throw error;
          });
        });
  }

}
