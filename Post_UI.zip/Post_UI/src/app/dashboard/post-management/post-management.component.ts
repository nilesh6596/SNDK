import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { ToasterService } from 'angular2-toaster';
import { WebStorageService, LOCAL_STORAGE } from 'angular-webstorage-service';
import { PostmgmtService } from '../../services/postmgmt.service';

@Component({
  selector: 'app-post-management',
  templateUrl: './post-management.component.html',
  styleUrls: ['./post-management.component.css']
})
export class PostManagementComponent implements OnInit {
  public searchString = '';
  public postData: any[];
  public postDataOfId: any[];
  public defaultGender: any;
  public tableDisplayValue = false;
  public totalRec: Number;
  public page = 1;
  public categoryList: any[];
  public postCount: any;
  public limit = 2;
  public startPointActive = 0;
  public status = 1;
  constructor(
    private _router: Router,
    private _postService: PostmgmtService,
    public _toasterService: ToasterService,
    @Inject(LOCAL_STORAGE)private _sessionstorage: WebStorageService
  ) { }

  ngOnInit() {
    this.getPostList();
    this.getCategoryList();
  }

  async getCategoryList() {
    await this.getCategoryData();
  }
  getCategoryData() {
    return new Promise((resolve, reject) => {
      this._postService.getCategoryDataAPI().subscribe((response) => {
        if (response.status_code === 200) {
          const categoryData = response.data;
          const list = [];
          categoryData.forEach(element => {
            list.push(element.category_name);
          });
          this.categoryList = list;
        }
        resolve();
      }, (error) => {
        this.popUpService('exception', 'Session Expired', 'Exception');
        throw error;
      });
    });
}

  async getPostList() {
    await this.getPostData();
  }

  popUpService(status, title, text) {
    this._toasterService.pop(status, title, text);
 }
  getPostData() {
    return new Promise(async (resolve, reject) => {
          const pagination = {};
          pagination['offset'] = this.startPointActive;
          pagination['limit'] = this.limit;
          this._postService.getPostDataAPI(pagination).subscribe(async (response: any) => {
            if (response && response.status_code === 200) {
              if (Array.isArray(response.data) && response.data.length > 0) {
                  this.tableDisplayValue = true;
                  this.postData = response.data[0];
                  this.postCount = response.data[1];
                  this.totalRec = this.postCount;
                } else {
                  this.popUpService('success', 'SUCCESS', 'No post data found..!!');
                  this.tableDisplayValue = false;
                }
            } else {
              this.popUpService('error', 'ERROR', 'Failed to get post data..!!');
            }
            resolve(response);
          },
          error => {
            this.popUpService('error', 'ERROR', 'Something went wrong..!!');
          });
        });
  }

  loadMoreData(pageNumber) {
    if (pageNumber === 1) {
      this.startPointActive = 0;
    } else {
      this.startPointActive = (pageNumber * 2) - 2;
    }
    this.getPostData();
  }

  addNewPostData() {
    this._router.navigate(['postDetails']);
  }

  deletePostDataPopUp (postId) {
    this.deletePostData(postId);
  }

  editPostData (postId) {
    document.getElementById('myModal').style.display = 'block';
    this._sessionstorage.set('postId', postId);
    this.getPostDataById(postId);
  }

  getPostDataById(postId) {
    return new Promise(async (resolve, reject) => {
          this._postService.getPostDataByIdAPI(postId).subscribe(async (response: any) => {
            if (response && response.status_code === 200) {
              this.postDataOfId = response.data;
            } else {
              this.popUpService('error', 'ERROR', 'Failed to get post data..!!');
            }
            resolve(response);
          },
          error => {
            this.popUpService('error', 'ERROR', 'Something went wrong..!!');
          });
        });
  }

  closeChatDilog() {
    this._sessionstorage.remove('postId');
    document.getElementById('myModal').style.display = 'none';
  }

  deletePostData(postId) {
    return new Promise(async (resolve, reject) => {
      this._postService.deletePostDataAPI(postId).subscribe(async (response: any) => {
        if (response && response.status_code === 200) {
          this.getPostData();
          this.popUpService('success', 'SUCCESS', 'Post data deleted successfully..!!');
        } else {
          this.popUpService('error', 'ERROR', 'Failed to get post data..!!');
        }
        resolve(response);
      },
      error => {
        this.popUpService('error', 'ERROR', 'Something went wrong..!!');
      });
    });
  }

  submit(form) {
    if (form.valid) {
        const formValues = form.value;
        this.updatePostData(formValues);
      } else {
      this.setFocusToInvalidElement(form);

      }
  }

  setFocusToInvalidElement(form) {
    if (!form.valid) {
      let target;
      target = document.getElementsByClassName('ng-invalid')[1];
      if (target) {
        target.focus();
      }
    }
  }

  updatePostData(formValues) {
    return new Promise(async (resolve, reject) => {
          const body = {};
          body['name'] = formValues.name;
          body['description'] = formValues.description;
          body['category'] = formValues.category;
          body['status'] = this.status;
          const postId = this._sessionstorage.get('postId');
          this._postService.updatePostDataAPI(body, postId).subscribe(async (response: any) => {
            if (response && response.status_code === 200) {
              this.popUpService('success', 'SUCCESS', 'Post data updated successfully..!!');
              document.getElementById('myModal').style.display = 'none';
              this._sessionstorage.remove('postId');
              this.getPostData();
              this._router.navigate(['/postManagement']);
            } else {
              this.popUpService('error', 'ERROR', 'Failed to update post data..!!');
            }
            resolve(response);
          },
          error => {
            this.popUpService('error', 'ERROR', 'Something went wrong..!!');
          });
        });
  }

  searchPost () {
    if (this.searchString.length > 0) {
      this.searchPosts();
    } else {
        this.getPostData();
    }
  }

  searchPosts () {
    return new Promise(async (resolve, reject) => {
      const body = {};
      body['postName'] = this.searchString;
      this._postService.getPostDataSearchAPI(body).subscribe(async (response: any) => {
        if (response && response.status_code === 200) {
          if (Array.isArray(response.data) && response.data.length > 0) {
              this.tableDisplayValue = true;
              this.postData = response.data;
              this.totalRec = this.postData.length;
            } else {
              this.popUpService('success', 'SUCCESS', 'No post data found..!!');
              this.tableDisplayValue = false;
            }
        } else {
          this.popUpService('error', 'ERROR', 'Failed to get post data..!!');
        }
        resolve(response);
      },
      error => {
        this.popUpService('error', 'ERROR', 'Something went wrong..!!');
      });
    });
  }

}
