import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { NopageComponent } from './nopage/nopage.component';
import { PostManagementComponent } from './post-management/post-management.component';
import { PostComponent } from './post/post.component';

export const dashboardRoutes: Routes = [

  { path: '', component: DashboardComponent,
      children: [
        { path: '', redirectTo: 'postManagement'},
        { path: 'postManagement', component: PostManagementComponent, pathMatch: 'full' },
        { path: 'postDetails', component: PostComponent, pathMatch: 'full' },
      ]
  },
  { path: '**', component: NopageComponent, pathMatch: 'full' },
];
export const dashboardrouting = RouterModule.forChild(dashboardRoutes);

@NgModule({
  imports: [dashboardrouting],
  exports: [RouterModule]
})

export class DashboardRoutingModule { }
