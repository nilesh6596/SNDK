import { CommonModule } from '@angular/common';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { dashboardrouting } from '../dashboard/dashboard.routing';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ToasterModule, ToasterService } from 'angular2-toaster';
import { DashboardComponent } from './dashboard.component';
import { RouterModule } from '@angular/router';
import { NopageComponent } from './nopage/nopage.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { PostComponent } from './post/post.component';
import { PostManagementComponent } from './post-management/post-management.component';
import { PostmgmtService } from '../services/postmgmt.service';


@NgModule({
  declarations: [
    DashboardComponent,
    NopageComponent,
    PostComponent,
    PostManagementComponent
    ],
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    dashboardrouting,
    FormsModule,
    ToasterModule,
    NgxPaginationModule
  ],
  providers: [ ToasterService, PostmgmtService ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class DashboardModule { }
