import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { WebStorageService, LOCAL_STORAGE } from 'angular-webstorage-service';
import { UserService } from '../../services/user.service';
import { ToasterService } from 'angular2-toaster';
import { AlertService } from '../../services/alert.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

public requestJson = this.createRequestJson();
public returnUrl: string;
public formValues: any;
public isOpen = true;
private isLoggedIn = false;

constructor(
      private _router: Router,
      private route: ActivatedRoute,
      private _loginUserService: UserService,
      public _toasterService: ToasterService,
      public _alertService: AlertService,
      @Inject(LOCAL_STORAGE)private _sessionstorage: WebStorageService
      ) {}

ngOnInit() {
      this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
}

createRequestJson() {
        const requestJson = {};
        requestJson['email'] = '';
        requestJson['password'] = '';
        return requestJson;
}

submit(form) {
        if (form.valid) {
            const formValues = form.value;
            this.loginUser(formValues);
        }
      }

popUpService(status, title, text) {
            this._toasterService.pop(status, title, text);
      }

loginUser(formValues) {
      return new Promise(async (resolve, reject) => {
            const body = {};
            body['email'] = formValues.email;
            body['password'] = formValues.password;
            this._loginUserService.getUserDetailsLOginAPI(body).subscribe(async (response: any) => {
              if (response && response.data.length > 0 && response.status_code === 200) {
                  this.isLoggedIn = true;
                  this.popUpService('success', 'SUCCESS', 'Logged in successfully..!!');
                  this._sessionstorage.set('UserLoggedIn', JSON.stringify(this.isLoggedIn));
                  this._sessionstorage.set('userCode', response.data[0].user_id);
                  this._sessionstorage.set('token', response.token);
                  this._sessionstorage.set('name', response.data[0].name);
                  this._router.navigate(['/home']);
              } else {
                  this.popUpService('error', 'ERROR', 'Failed to logged in..!!');
              }
              resolve(response);
            },
            error => {
                  this.popUpService('error', 'ERROR', 'Something went wrong..!!');
                });
          });
 }



}
