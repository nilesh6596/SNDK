import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login/login.component';
import { RegisterComponent } from './register/register/register.component';
import { AuthGuard } from './dashboard/auth.guard';

const appRoutes: Routes = [
  // otherwise redirect to home
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  {
    path: 'home',
    canActivateChild: [AuthGuard],
    loadChildren: './dashboard/dashboard.module#DashboardModule'
  }
];

export const routing = RouterModule.forRoot(appRoutes);
